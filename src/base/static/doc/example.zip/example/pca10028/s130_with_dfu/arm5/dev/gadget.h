#ifndef GADGET_H__
#define GADGET_H__
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#define REQUEST_CNT 2
#define EVENT_CNT 1
typedef void (*ep_hnd) (void* self, void* cb_data);
typedef void (*p_endpoints) (ep_hnd* self, void* data);

static char MIB_PRODUCT_NAME[] = "mibio";  // max 12 char
static p_endpoints endpoints[REQUEST_CNT];
static uint32_t return_size[REQUEST_CNT];

typedef enum
{ 
  MIB_EP_CLEAR_PIN = 0,
  MIB_EP_SET_PIN = 1,
} request_ids;


typedef struct clear_pin_t clear_pin_t;
struct clear_pin_t
{ 
  uint8_t pin_number;
};

typedef struct clear_pin_return_t clear_pin_return_t;
struct clear_pin_return_t
{ 
  uint8_t result;
};
static clear_pin_return_t* clear_pin_return_size;

typedef struct set_pin_t set_pin_t;
struct set_pin_t
{ 
  uint8_t pin_number;
};

typedef struct set_pin_return_t set_pin_return_t;
struct set_pin_return_t
{ 
  uint8_t result;
};
static set_pin_return_t* set_pin_return_size;



typedef enum
{ 
  MIB_EVT_PIN_INTERRUPT = 0,
} event_ids;

typedef struct pin_interrupt_t pin_interrupt_t;
struct pin_interrupt_t
{ 
  uint8_t pin_number;
  uint8_t pin_state;
};



void clear_pin(ep_hnd* _hnd, clear_pin_t* data_t);
void set_pin(ep_hnd* _hnd, set_pin_t* data_t);

#ifndef GADGET_INIT__
#define GADGET_INIT__
static void mib_init(void) {
  
  endpoints[MIB_EP_CLEAR_PIN] = clear_pin;
  return_size[MIB_EP_CLEAR_PIN] = sizeof(*clear_pin_return_size);

  endpoints[MIB_EP_SET_PIN] = set_pin;
  return_size[MIB_EP_SET_PIN] = sizeof(*set_pin_return_size);

}
#endif // GADGET_INIT__
#endif // GADGET_H__