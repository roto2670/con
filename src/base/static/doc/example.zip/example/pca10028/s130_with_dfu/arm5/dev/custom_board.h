/* 
 * Copyright 2012-2013 Narantech Inc. All rights reserved.
*/
#ifndef CUSTOM_H
#define CUSTOM_H

// LEDs definitions for Microbot push
#define LEDS_NUMBER    3
#define LED_START      8
#define LED_1          8  // BLUE
#define LED_2          9  // GREEN
#define LED_3          10  // RED
#define LED_STOP       10
#define LEDS_LIST { LED_1, LED_2, LED_3 }
#define BSP_LED_0      LED_1
#define BSP_LED_1      LED_2
#define BSP_LED_2      LED_3
#define BSP_LED_0_MASK (1<<BSP_LED_0)
#define BSP_LED_1_MASK (1<<BSP_LED_1)
#define BSP_LED_2_MASK (1<<BSP_LED_2)
#define LEDS_MASK      (BSP_LED_0_MASK | BSP_LED_1_MASK | BSP_LED_2_MASK)
#define LEDS_INV_MASK  LEDS_MASK

#define BUTTONS_NUMBER 1
#define BUTTON_START   22
#define BUTTON_1       22
#define BUTTON_STOP   22
#define BUTTON_PULL    NRF_GPIO_PIN_PULLUP
#define BUTTONS_LIST { BUTTON_1}
#define BSP_BUTTON_0   BUTTON_1
#define BSP_BUTTON_0_MASK (1<<BSP_BUTTON_0)
#define BUTTONS_MASK   (BSP_BUTTON_0_MASK)

#endif // CUSTOM_H
