/* Copyright (c) 2012 Nordic Semiconductor. All Rights Reserved.
 *
 * The information contained herein is property of Nordic Semiconductor ASA.
 * Terms and conditions of usage are described in detail in NORDIC
 * SEMICONDUCTOR STANDARD SOFTWARE LICENSE AGREEMENT.
 *
 * Licensees are granted free, non-transferable use of the information. NO
 * WARRANTY of ANY KIND is provided. This heading must NOT be removed from
 * the file.
 *
 */

/** @file
 *
 * @defgroup ble_sdk_srv_bas Microbot Service
 * @{
 * @ingroup ble_sdk_srv
 * @brief Microbot Service module.
 *
 * @details This module implements the Microbot Service with the Microbot characteristic.
 *          During initialization it adds the Microbot Service and Microbot characteristic
 *          to the BLE stack database. Optionally it can also add a Report Reference descriptor
 *          to the Microbot characteristic (used when including the Microbot Service in
 *          the HID service).
 *
 *
 *
 * @note Attention!
 *  To maintain compliance with Nordic Semiconductor ASA Bluetooth profile
 *  qualification listings, this section of source code must not be modified.
 */

#ifndef MICROBOT_H__
#define MICROBOT_H__

#include <stdint.h>
#include <string.h>
#include <math.h>
#include "nordic_common.h"
#include "nrf.h"
#include "app_error.h"
#include "app_timer.h"
#include "ble.h"
#include "bsp.h"
#include "bsp_btn_ble.h"
#include "ble_hci.h"
#include "ble_srv_common.h"
#include "ble_advdata.h"
#include "ble_advertising.h"
#include "ble_dis.h"
#include "ble_conn_params.h"
#include "boards.h"
#ifdef BLE_DFU_APP_SUPPORT
#include "ble_dfu.h"
#include "dfu_app_handler.h"
#endif // BLE_DFU_APP_SUPPORT
#include "device_manager.h"
#include "nrf_delay.h"
#ifdef NRF51
#include "nrf_adc.h"
#elif NRF52
#include "nrf_saadc.h"
#include "nrf_drv_saadc.h"
#include "nrf_drv_ppi.h"
#include "nrf_drv_timer.h"
#endif
#include "nrf_drv_gpiote.h"
#include "nrf_drv_rng.h"
#include "pstorage.h"
#include "softdevice_handler.h"

#include "gadget.h"

#define PRODUCT_NAME_LEN 12




/* Gadget variables */
typedef enum
{
  MIB_SUCCESS = 0xF000,
  MIB_OTP_FAILED,
  MIB_REQ_ID_MATCH_FAILED,
  MIB_SEQENCE_FAILED,
  MIB_DATA_LENGTH_OVERFLOW,
  MIB_DATA_CRC_CHK_ERROR,
  MIB_INCORRECT_EPID,
  MIB_REQUEST_TIMEOUT,
  MIB_REQUEST_BUF_FULL,
  MIB_HAS_NOT_REQUEST,
  MIB_BUSY,
  MIB_ERROR,
} gadget_return_type_t;

/* led bit */
#define RED    1
#define GREEN  2
#define BLUE   4
#define OFF    8
#define LED_MODEL_LEN 19
#define LED_MIN_INTERVAL 100


/**@brief BSP events.
 *
 * @note Events from BSP_EVENT_KEY_0 to BSP_EVENT_KEY_LAST are by default assigned to buttons.
 */
typedef enum
{
  MIB_EVT_REVEAL,                  /**< reveal requested event. */
  MIB_EVT_BATT_CHANGED,
  MIB_EVT_CONNECTED,
  MIB_EVT_DISCONNECTED,
  MIB_EVT_TRY_CONNECT,
  MIB_EVT_TRY_PAIR,
  MIB_EVT_TRY_REMOVE,
  MIB_EVT_BTN_PUSH,
  MIB_EVT_BTN_RELEASE,
  MIB_EVT_BTN_LONG_PUSH,
  MIB_EVT_BTN_HALF_LONG_PUSH,
  MIB_EVT_SYNC_TIME,
  MIB_EVT_SET_LED,
  MIB_EVT_GET_INFO,
	MIB_EVT_GET_BATT,
} ble_microbot_evt_type_t;

/**@brief Microbot event. */
typedef struct
{
  ble_microbot_evt_type_t evt_type;                                  /**< Type of event. */
} ble_microbot_evt_t;


// Forward declaration of the ble_bas_t type.
typedef struct ble_microbot_s ble_microbot_t;


/**@brief Microbot Service event handler type. */
typedef void (*ble_microbot_evt_handler_t) (ble_microbot_evt_t * p_evt);


/**@brief Microbot Service init structure. This contains all options and data needed for
 *        initialization of the service.*/
typedef struct
{
  ble_microbot_evt_handler_t         evt_handler;                    /**< Event handler to be called for handling events in the Microbot Service. */
  ble_srv_report_ref_t *             p_report_ref;                   /**< If not NULL, a Report Reference descriptor with the specified value will be added to the Microbot characteristic */
  ble_srv_cccd_security_mode_t       microbot_char_attr_md;     /**< Initial security level for microbot characteristics attribute */
  ble_gap_conn_sec_mode_t            microbot_report_read_perm; /**< Initial security level for microbot report read attribute */
  bool                               batt_support_notification;
  uint32_t                           led_red;
  uint32_t                           led_green;
  uint32_t                           led_blue;
  uint32_t                           evt_button_push;
  uint8_t                            app_version_major;
  uint8_t                            app_version_minor;
  uint8_t                            app_version_build;
  uint8_t                            board_revision_major;
  uint8_t                            board_revision_minor;
  uint32_t                           max_batt;
  uint32_t                           min_batt;
  bool                               bsp_button_high_to_low;
  char*                              product_name;
  uint8_t *                          dev_org_name;
  uint16_t                           dev_org_len;
  ble_gap_addr_t                     mib_addr;
} ble_microbot_init_t;


/**@brief Microbot Service structure. This contains various status information for the service. */
struct ble_microbot_s
{
  ble_microbot_evt_handler_t        evt_handler;                    /**< Event handler to be called for handling events in the Microbot Service. */
  uint16_t                          service_handle;                 /**< Handle of Microbot Service (as provided by the BLE stack). */

  /* gadget */
  ble_gatts_char_handles_t          common_handles;
  ble_gatts_char_handles_t          communication_handles;
#ifdef NRF51
  nrf_adc_config_input_t            current_input;
#elif NRF52
  nrf_saadc_input_t                 current_input;
#endif
  uint16_t                          report_ref_handle;              /**< Handle of the Report Reference descriptor. */
  uint16_t                          conn_handle;                    /**< Handle of the current connection (as provided by the BLE stack, is BLE_CONN_HANDLE_INVALID if not in a connection). */
  uint8_t                           core_version_major;
  uint8_t                           core_version_minor;
  uint8_t                           app_version_major;
  uint8_t                           app_version_minor;
  uint8_t                           board_version_major;
  uint8_t                           board_version_minor;
  uint16_t                          reveal_sec;
  uint32_t                          max_batt;
  uint32_t                          min_batt;
  uint8_t                           batt_level;
  uint32_t                          adc_var;
  uint32_t                          led_red;
  uint32_t                          led_green;
  uint32_t                          led_blue;
  bool                              bsp_button_high_to_low;
  char                              device_tag[PRODUCT_NAME_LEN];
  uint8_t *                         dev_org_name;
  uint8_t                           dev_org_len;
  ble_advdata_manuf_data_t          mib_name;
  ble_gap_addr_t                    mib_addr;
};

typedef struct charactoristic_elements
{
  uint16_t                        service_handle;
  uint16_t                        report_ref_handle;
  ble_srv_report_ref_t *          p_report_ref;                   /**< If not NULL, a Report Reference descriptor with the specified value will be added to the Microbot characteristic */
  ble_srv_cccd_security_mode_t    microbot_char_attr_md;     /**< Initial security level for microbot characteristics attribute */
  ble_gap_conn_sec_mode_t         microbot_report_read_perm;
} char_add_element_t;


/* gadget public func */

uint16_t mib_return(ep_hnd* _hnd, void* data_t);
uint16_t mib_event_write(uint16_t event_id, void* event_data, uint32_t data_len);

/**@brief Function for initialize microbot
 *
 * @details initialize ble evt, battery, led, adc, flash memory... about microbot
 *
 */
uint32_t mib_initialize(ble_microbot_init_t  p_microbot_init);

/**@brief Function for start microbot
 *
 * @details start application timer, advertising and microbot
 *
 */
void start_microbot(void);


/****************LED*************/

/**@brief Function for led on
 *
 *
 * @param[in]   led_color          Set color RED,GREEN,BLUE
 *
 */
void on_led(uint8_t color);


/**@brief Function for led off
 *
 *
 * @param[in]   led_color           Set color RED,GREEN,BLUE
 *
 */
void off_led(uint8_t color);


/**@brief Function for led invert
 *
 *
 * @param[in]   led_color           Set color RED,GREEN,BLUE
 *
 */
void invert_led(uint8_t color);

/**@brief Function for off all leds;
 *
 *
 */
void off_all_led(void);

/**@brief Function for off blink led
 *
 *    off led and off blink timer
 *
 */

/***************FLASH MEMORY*********************/

/**@brief Function for store pstorage
 *
 * @param[in]   store_data           Set store data into flash memory
 * @param[in]   store_size           Set size of store data, must be a multiple of word size (4bytes)
 * @param[in]   mib_handle         Choose pstorage handler to store
 * @param[in]   block_num          Get identifier about pstorge handler
 * @param[in]   clear_size           For clear before store
 *
 */
uint32_t mib_pstorage_store(uint8_t * store_data, pstorage_handle_t * mib_handle, pstorage_size_t block_num);

/**@brief Function for load pstorage
 *
 * @param[in]   load_data            Load data from flash memory
 * @param[in]   load_size             Set size of load data, must be a multiple of word size (4bytes)
 * @param[in]   mib_handle         Choose pstorage handler to store
 * @param[in]   block_num          Get identifier about pstorge handler
 *
 */
uint32_t mib_pstorage_load(uint8_t * load_data, pstorage_handle_t * mib_handle, pstorage_size_t block_num);


uint32_t get_UTC_time(void);

void load_peer_addr_handler(void * p_context);
void force_switch_advertising_stop(void);
void force_switch_advertising_start(void);

#endif // MICROBOT_H__

/** @} */
