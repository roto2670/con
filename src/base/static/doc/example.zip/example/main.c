/* Copyright (c) 2014 Nordic Semiconductor. All Rights Reserved.
 *
 * The information contained herein is property of Nordic Semiconductor ASA.
 * Terms and conditions of usage are described in detail in NORDIC
 * SEMICONDUCTOR STANDARD SOFTWARE LICENSE AGREEMENT.
 *
 * Licensees are granted free, non-transferable use of the information. NO
 * WARRANTY of ANY KIND is provided. This heading must NOT be removed from
 * the file.
 *
 */
/** @example examples/ble_peripheral/ble_app_hrs/main.c
 *
 * @brief Heart Rate Service Sample Application main file.
 *
 * This file contains the source code for a sample application using the Heart Rate service
 * (and also Battery and Device Information services). This application uses the
 * @ref srvlib_conn_params module.
 */


#include "microbot.h"
#include "gadget.h"

#include "nrf_gpio.h"
#include "nrf_drv_gpiote.h"

#define MIN_BATTERY_LEVEL               640                                        /**< Minimum simulated battery level.  2.7V*/     //0%
#define MAX_BATTERY_LEVEL               770                                       /**< Maximum simulated battery level. 4.1V*/ //    100%
#define BOARD_REVISION_MAJOR            0
#define BOARD_REVISION_MINOR            1
#define APP_VERSION_MAJOR               3
#define APP_VERSION_MINOR               37

#define INTERRUPT_PIN 12

typedef struct io_model_t io_t;
struct io_model_t
{
  bool paired;
};

static ble_microbot_init_t        microbot_init;
static io_t                       m_io;

void microbot_evt_handler(ble_microbot_evt_t * p_evt)
{
  switch (p_evt->evt_type)
  {
  case MIB_EVT_REVEAL:
    break;
  case MIB_EVT_CONNECTED:
    m_io.paired = true;
    break;
  case MIB_EVT_DISCONNECTED:
    m_io.paired = false;
    break;
  case MIB_EVT_BTN_PUSH:
    break;
  case MIB_EVT_BTN_RELEASE:
    break;
  case MIB_EVT_BTN_LONG_PUSH:
    break;
  default:
    break;
  }
}

/* mib endpoint */
void set_pin(ep_hnd* _hnd, set_pin_t* data)
{
  nrf_gpio_cfg_output(data->pin_number);
  nrf_gpio_pin_set(data->pin_number);
  mib_return(_hnd, data);
}
void clear_pin(ep_hnd* _hnd, clear_pin_t* data)
{
  nrf_gpio_cfg_output(data->pin_number);
  nrf_gpio_pin_clear(data->pin_number);
  mib_return(_hnd, data);
}
/* mib */

static void init()
{
  uint32_t err_code;

  microbot_init.evt_handler          = microbot_evt_handler;
  microbot_init.p_report_ref         = NULL;
  microbot_init.led_red                = BSP_LED_2_MASK;
  microbot_init.led_green            = BSP_LED_1_MASK;
  microbot_init.led_blue               = BSP_LED_0_MASK;
  microbot_init.max_batt               = MAX_BATTERY_LEVEL;
  microbot_init.min_batt                = MIN_BATTERY_LEVEL;
  microbot_init.board_revision_major     = BOARD_REVISION_MAJOR;
  microbot_init.board_revision_minor     = BOARD_REVISION_MINOR;
  microbot_init.app_version_major         = APP_VERSION_MAJOR;
  microbot_init.app_version_minor         = APP_VERSION_MINOR;
  microbot_init.bsp_button_high_to_low        = true;

  err_code = mib_initialize(microbot_init);
  APP_ERROR_CHECK(err_code);
}

void interrupt_handler(nrf_drv_gpiote_pin_t pin, nrf_gpiote_polarity_t action)
{
  pin_interrupt_t data;
  data.pin_number = (uint8_t)pin;
  data.pin_state = action;
  mib_event_write(MIB_EVT_PIN_INTERRUPT, &data, sizeof(pin_interrupt_t));
}

static void pin_interrupt_init()
{
  // gyro gpio interrupt
  nrf_drv_gpiote_in_config_t pin_interrupt_config_in = GPIOTE_CONFIG_IN_SENSE_TOGGLE(false);
  pin_interrupt_config_in.pull = NRF_GPIO_PIN_PULLDOWN;
  nrf_drv_gpiote_in_init(INTERRUPT_PIN, &pin_interrupt_config_in, interrupt_handler);
  nrf_drv_gpiote_in_event_enable(INTERRUPT_PIN, true);
}

/**@brief Function for application main entry.
 */
int main(void)
{
  // Initialize.
  init();
  pin_interrupt_init();
  // Start execution.
  start_microbot();
}
