// Step 1 : just add this header!!
#include "gadget.h"

#include "nrf_gpio.h"
#include "nrf_drv_gpiote.h"

// Step 2 : for the mib_init_t 
#define LED_0                 17//8         // BLUE     10040DK(17), IO(8)
#define LED_1                 18//9         // GREEN    10040DK(18), IO(9)
#define LED_2                 19//10        // RED      10040DK(19), IO(10)
#define BUTTON_0              13//22        // BTN      10040DK(13), IO(13)
#define MIN_BATTERY_LEVEL     640       /**< Minimum battery level.  2.7V*/     //0%
#define MAX_BATTERY_LEVEL     770       /**< Maximum battery level. 4.1V*/ //    100%
#define BOARD_REVISION_MAJOR  0
#define BOARD_REVISION_MINOR  1
#define APP_VERSION_MAJOR     3
#define APP_VERSION_MINOR     37
#define INTERRUPT_PIN         12
#define BATT_INPUT_PIN        NRF_ADC_CONFIG_INPUT_2


// Step 3 : define mib_init_t 
static mib_init_t        microbot_init;

// Step 4 : microbot-nrf event_handler, more case 'Microbot sdk document'
void microbot_evt_handler(ble_microbot_evt_t * p_evt)
{
  switch (p_evt->evt_type)
  {
  case MIB_EVT_REVEAL:
    break;
  case MIB_EVT_CONNECTED:
    break;
  case MIB_EVT_DISCONNECTED:
    break;
  case MIB_EVT_BTN_PUSH:
    break;
  case MIB_EVT_BTN_RELEASE:
    break;
  case MIB_EVT_BTN_LONG_PUSH:
    break;
  default:
    break;
  }
}

// Step 5 : Copy & Paste of endpoint functions in gadget.h
//          and Definition of endpoints
void set_pin(ep_hnd* _hnd, set_pin_t* data)
{
  nrf_gpio_cfg_output(data->pin_number);
  nrf_gpio_pin_set(data->pin_number);
  mib_return(_hnd, data);
}
void clear_pin(ep_hnd* _hnd, clear_pin_t* data)
{
  nrf_gpio_cfg_output(data->pin_number);
  nrf_gpio_pin_clear(data->pin_number);
  mib_return(_hnd, data);
}

uint8_t battery_calibration(uint32_t adc_level)
{
  uint8_t formula_res = 0;
  formula_res = (double)((double)(adc_level - MIN_BATTERY_LEVEL) / (double)(MAX_BATTERY_LEVEL - MIN_BATTERY_LEVEL)) * 100.0;
  return formula_res;
}

static void init()
{
  uint32_t err_code;
  
  microbot_init.led_red_pin_number = LED_2;
  microbot_init.led_green_pin_number = LED_1;
  microbot_init.led_blue_pin_number  = LED_0;
  microbot_init.button_pin_number = BUTTON_0;
  microbot_init.button_active_state  = false;
  microbot_init.bsp_button_pull = NRF_GPIO_PIN_PULLUP;
  
  microbot_init.max_batt  = MAX_BATTERY_LEVEL;
  microbot_init.min_batt  = MIN_BATTERY_LEVEL;
  microbot_init.battry_ain_pin_number = NRF_SAADC_INPUT_AIN0;
  microbot_init.evt_handler = microbot_evt_handler;

  microbot_init.enable_watchdog = MIB_WDT_ENABLE;
  microbot_init.custom_formular = battery_calibration;

  // Step 6 : call 'mib_init()'! do not call 'mib_initialize()'
  err_code = mib_init(&microbot_init);
  APP_ERROR_CHECK(err_code);
}

void interrupt_handler(nrf_drv_gpiote_pin_t pin, nrf_gpiote_polarity_t action)
{
  pin_interrupt_t data;
  data.pin_number = (uint8_t)pin;
  data.pin_state = action;
  // Step 7 : raise event definition like this function
  mib_event_write(MIB_EVT_PIN_INTERRUPT, &data, sizeof(pin_interrupt_t));
}

static void pin_interrupt_init()
{
  // gyro gpio interrupt
  nrf_drv_gpiote_in_config_t pin_interrupt_config_in = GPIOTE_CONFIG_IN_SENSE_TOGGLE(false);
  pin_interrupt_config_in.pull = NRF_GPIO_PIN_PULLDOWN;
  nrf_drv_gpiote_in_init(INTERRUPT_PIN, &pin_interrupt_config_in, interrupt_handler);
  nrf_drv_gpiote_in_event_enable(INTERRUPT_PIN, true);
}

int main(void)
{
  init();
  pin_interrupt_init();
  // Step 8 : call microbot service loop
  start_microbot();
}