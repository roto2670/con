/* Copyright (c) 2012 Nordic Semiconductor. All Rights Reserved.
 *
 * The information contained herein is property of Nordic Semiconductor ASA.
 * Terms and conditions of usage are described in detail in NORDIC
 * SEMICONDUCTOR STANDARD SOFTWARE LICENSE AGREEMENT.
 *
 * Licensees are granted free, non-transferable use of the information. NO
 * WARRANTY of ANY KIND is provided. This heading must NOT be removed from
 * the file.
 *
 */

/** @file
 *
 * @defgroup ble_sdk_srv_bas Microbot Service
 * @{
 * @ingroup ble_sdk_srv
 * @brief Microbot Service module.
 *
 * @details This module implements the Microbot Service with the Microbot characteristic.
 *          During initialization it adds the Microbot Service and Microbot characteristic
 *          to the BLE stack database. Optionally it can also add a Report Reference descriptor
 *          to the Microbot characteristic (used when including the Microbot Service in
 *          the HID service).
 *
 *
 *
 * @note Attention!
 *  To maintain compliance with Nordic Semiconductor ASA Bluetooth profile
 *  qualification listings, this section of source code must not be modified.
 */

#ifndef MICROBOT_H__
#define MICROBOT_H__

#include <stdint.h>
#include <string.h>
#include <math.h>
#include "nordic_common.h"
#include "nrf.h"
#include "app_error.h"
#include "app_timer.h"
#include "ble.h"
#include "mib_bsp.h"
#include "bsp_btn_ble.h"
#include "ble_hci.h"
#include "ble_srv_common.h"
#include "ble_advdata.h"
#include "ble_advertising.h"
#include "ble_dis.h"
#include "ble_conn_params.h"
#ifdef BLE_DFU_APP_SUPPORT
#include "ble_dfu.h"
#include "dfu_app_handler.h"
#endif // BLE_DFU_APP_SUPPORT
#include "device_manager.h"
#include "nrf_delay.h"
#ifdef NRF51
#include "nrf_adc.h"
#elif NRF52
#include "nrf_saadc.h"
#include "nrf_drv_saadc.h"
#include "nrf_drv_ppi.h"
#include "nrf_drv_timer.h"
#endif
#include "nrf_drv_rng.h"
#include "pstorage.h"
#include "softdevice_handler.h"

#define RED    1
#define GREEN  2
#define BLUE   4
#define OFF    8
#define PRODUCT_NAME_LEN 12
//#define TEST_MODE 1

typedef uint16_t (*ep_hnd) (void* self, void* cb_data);
typedef void (*p_endpoints) (ep_hnd* self, void* data);

/* Gadget variables */
typedef enum
{
  MIB_SUCCESS = 0x0000,
  MIB_OTP_FAILED = 0xE000,
  MIB_WRONG_INIT_VALUES = 0xE001,
  MIB_PSTORAGE_INVALID_BLOCK_NUMBER = 0xE002,
  MIB_PSTORAGE_INVALID_OFFSET_OR_SIZE = 0xE003,
  MIB_REQ_ID_MATCH_FAILED = 0xE004,
  MIB_SEQENCE_FAILED = 0xE005,
  MIB_DATA_LENGTH_OVERFLOW = 0xE006,
  MIB_DATA_CRC_CHK_ERROR = 0xE007,
  MIB_INCORRECT_EPID = 0xE008,
  MIB_REQUEST_RETURN_TIMEOUT = 0xE009,
  MIB_REQUEST_BUF_FULL = 0xE00A,
  MIB_HAS_NOT_REQUEST = 0xE00B,
  MIB_NOTIFICATION_BUFFER_FULL = 0xE00C,
  MIB_ALREADY_PAIRED = 0xE00D,
  MIB_BUSY = 0xE00E,
  MIB_NOT_FOUND_REQUST_ID = 0xE00F,
  MIB_UNKNOWN_ERROR = 0xE010,
  MIB_PACKET_TIMEOUT = 0xE011,
  MIB_IS_NOT_PAIRED = 0xE012,
  MIB_UNAUTHORIZED = 0xE013,
  MIB_CONNECT_TIMEOUT = 0xE014,
  MIB_PAIR_TIMEOUT = 0xE015,
  MIB_PACKET_RECV_TIMEOUT = 0xE016,
  
} gadget_return_type_t;

/**@brief BSP events.
 *
 * @note Events from BSP_EVENT_KEY_0 to BSP_EVENT_KEY_LAST are by default assigned to buttons.
 */
typedef enum
{
  MIB_EVT_INIT = 0x0000,
  MIB_EVT_REVEAL = 0xF000,                  /**< reveal requested event. */
  MIB_EVT_BATT_CHANGED,
  MIB_EVT_CONNECTED,
  MIB_EVT_DISCONNECTED,
  MIB_EVT_TRY_REMOVE,
  MIB_EVT_BTN_PUSH,
  MIB_EVT_BTN_RELEASE,
  MIB_EVT_BTN_LONG_PUSH,
  MIB_EVT_BTN_HALF_LONG_PUSH,
  MIB_EVT_SYNC_TIME,
  MIB_EVT_RESET,
} ble_microbot_evt_type_t;

/**@brief Microbot event. */
typedef struct
{
  ble_microbot_evt_type_t evt_type;                                  /**< Type of event. */
} ble_microbot_evt_t;

/**@brief Microbot Service event handler type. */
typedef void (*ble_microbot_evt_handler_t) (ble_microbot_evt_t * p_evt);
typedef uint8_t (*batt_level_formular)(uint32_t batt_level);

/**@brief Microbot Service init structure. This contains all options and data needed for
 *        initialization of the service.*/
typedef struct
{
  ble_microbot_evt_handler_t         evt_handler;
  uint32_t                           led_red_pin_number;
  uint32_t                           led_green_pin_number;
  uint32_t                           led_blue_pin_number;
  uint32_t                           button_pin_number;
  bool                               button_active_state;
  uint8_t                            bsp_button_pull;
  uint32_t                           max_batt;
  uint32_t                           min_batt;
#ifdef NRF51
  nrf_adc_config_input_t             battry_ain_pin_number;
#elif NRF52
  nrf_saadc_input_t                  battry_ain_pin_number;
#endif
  batt_level_formular*               custom_formular;
// do not set below variable
  uint8_t                            product_name[PRODUCT_NAME_LEN];
  uint8_t                            sdk_version_major;
  uint8_t                            sdk_version_minor;
  uint16_t                           model_number;
  uint8_t                            firmware_version_major;
  uint8_t                            firmware_version_minor;
  uint8_t                            firmware_build_number;
  uint32_t                           endpoint_length;
  p_endpoints*                       endpoints;
  uint32_t*                          return_size;
} mib_init_t;
static mib_init_t microbot_initialize;

/*****FOR_LED*******/
typedef struct led_model
{
  uint8_t  color_len;
  uint16_t interval;
  uint8_t  repeat_count;
  uint8_t  color[12];
  uint16_t show_led_index;
  uint8_t  is_work;
} led_model_t;


/**@brief Function for initialize microbot
 *
 * @details initialize ble evt, battery, led, adc, flash memory... about microbot
 *
 */
uint16_t mib_initialize(mib_init_t* init_data);
/**@brief Function for start microbot
 *
 * @details start application timer, advertising and microbot
 *
 */
void start_microbot(void);
/**@brief Function for start microbot
 *
 * @details start application timer, advertising and microbot
 *
 */
uint16_t mib_request_action(void);
/**@brief Function for endpoint return 
 *
 * @details 
 *
 */
uint16_t mib_return(ep_hnd* _hnd, void* data_t);

/**@brief Function for dynamic return
 *
 * @details 
 *
 */
uint16_t mib_return_dynamic(ep_hnd* _hnd, void* data_t, uint32_t packet_length);

/**@brief Function for send notification to central 
 *
 * @details 
 *
 */
uint16_t mib_event_write(uint16_t event_id, void* event_data, uint32_t data_len);

/****************LED*************/

/**@brief Function for led on
 *
 *
 * @param[in]   led_color          Set color RED,GREEN,BLUE
 *
 */
void on_led(uint8_t color);


/**@brief Function for led off
 *
 *
 * @param[in]   led_color           Set color RED,GREEN,BLUE
 *
 */
void off_led(uint8_t color);


/**@brief Function for led invert
 *
 *
 * @param[in]   led_color           Set color RED,GREEN,BLUE
 *
 */
void invert_led(uint8_t color);

/**@brief Function for off all leds;
 *
 *
 */
void off_all_led(void);

/**@brief Function for off blink led
 *
 *    off led and off blink timer
 *
 */
void blink_led(led_model_t* blink_led_data);

/**@brief Function for get batt adc level
 *
 *    off led and off blink timer
 *
 */
uint16_t get_adc_level(void);
/***************FLASH MEMORY*********************/

/**@brief Function for store pstorage
 *
 * @param[in]   store_data           Set store data into flash memory
 * @param[in]   store_size           Set size of store data, must be a multiple of word size (4bytes)
 * @param[in]   mib_handle         Choose pstorage handler to store
 * @param[in]   block_num          Get identifier about pstorge handler
 * @param[in]   clear_size           For clear before store
 *
 */
uint16_t mib_pstorage_store(uint8_t * store_data, pstorage_handle_t * mib_handle, uint8_t block_num, uint8_t offset, uint8_t p_size);

/**@brief Function for load pstorage
 *
 * @param[in]   load_data            Load data from flash memory
 * @param[in]   load_size             Set size of load data, must be a multiple of word size (4bytes)
 * @param[in]   mib_handle         Choose pstorage handler to store
 * @param[in]   block_num          Get identifier about pstorge handler
 *
 */
uint16_t mib_pstorage_load(uint8_t * load_data, pstorage_handle_t * mib_handle, uint8_t block_num, uint8_t offset, uint8_t p_size);

/**@brief Function for get utc time
 *
 * @details 
 *
 */
uint32_t get_UTC_time(void);

/**@brief Function for get booting time (unit : second)
 *
 * @details 
 *
 */
uint32_t get_system_time(void);

/**@brief Function for confirm of custom pair
 *
 * @details 
 *
 */
void do_confirm_pair(void);

/**@brief Function for delete microbot infomation in flash memory
 *
 * @details 
 *
 */
uint16_t delete_microbot(void);

/**@brief Function for delete microbot infomation in flash memory
 *
 * @details 
 *
 */
void mib_mock_ep_packet_test(uint8_t* header, uint8_t* body, uint32_t body_packet_count);
#endif // MICROBOT_H__

/** @} */
